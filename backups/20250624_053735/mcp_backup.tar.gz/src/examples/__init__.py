"""
Exemples d'utilisation des différentes fonctionnalités du projet MCP.

Ce package contient des exemples pratiques pour illustrer l'utilisation
des différentes API et composants du projet.
""" 