"""
Module API pour MCP
Expose les endpoints pour le simulateur de nœuds et l'optimiseur de frais.

Dernière mise à jour: 9 mai 2025
""" 