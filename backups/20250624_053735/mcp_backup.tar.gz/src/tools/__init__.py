"""
Outils utilitaires pour MCP
Inclut des outils pour la simulation, le test de charge, et d'autres utilitaires.

Dernière mise à jour: 9 mai 2025
""" 