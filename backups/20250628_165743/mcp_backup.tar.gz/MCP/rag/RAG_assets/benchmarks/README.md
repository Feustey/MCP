# benchmarks

Ce dossier contient des benchmarks de performance pour les nœuds Lightning (tests de latence, throughput, uptime, comparatifs hardware/software, etc.).

Utilité :
- Permettre au RAG de conseiller sur le dimensionnement et l'optimisation des nœuds.
- Alimenter les recommandations d'architecture et de choix d'infrastructure.

Ajoutez ici des fichiers CSV, Markdown ou rapports de tests. 