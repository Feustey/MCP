# logs

Ce dossier contient des journaux d'événements (logs) pour chaque nœud Lightning, organisés par date.

Utilité :
- Permettre au RAG d'analyser les incidents, détecter des patterns de stabilité ou d'erreurs.
- Alimenter les recommandations de monitoring et de maintenance.

Ajoutez ici des fichiers de logs anonymisés ou extraits pertinents. 