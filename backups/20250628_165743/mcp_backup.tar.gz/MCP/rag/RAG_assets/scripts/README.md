# scripts

Ce dossier contient des scripts d'automatisation pour la gestion avancée des nœuds Lightning (gestion des frais, rebalancement, monitoring, alertes, etc.).

Utilité :
- Permettre au RAG de proposer des solutions d'automatisation adaptées à chaque contexte.
- Accélérer la mise en œuvre des recommandations techniques.

Ajoutez ici des scripts Python, Bash, ou tout autre langage pertinent, accompagnés d'un fichier README d'utilisation. 