# faq

Ce dossier contient des FAQ, retours d'expérience et bonnes pratiques pour l'exploitation et la configuration de nœuds Lightning.

Utilité :
- Permettre au RAG de répondre aux questions fréquentes et de proposer des solutions éprouvées.
- Alimenter les recommandations pratiques et contextualisées.

Ajoutez ici des fichiers Markdown ou texte pour chaque thème ou question fréquente. 