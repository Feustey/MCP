# config_examples

Ce dossier contient des exemples de fichiers de configuration pour différents logiciels Lightning (LND, c-lightning, Eclair, etc.).

Utilité :
- Permettre au RAG de générer des recommandations de configuration précises et contextualisées.
- Servir de référence pour l'analyse de configurations existantes ou la génération de guides d'installation.

Ajoutez ici des fichiers anonymisés ou des extraits pertinents de configuration. 