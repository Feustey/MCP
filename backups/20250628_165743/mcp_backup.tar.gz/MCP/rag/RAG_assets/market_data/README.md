# market_data

Ce dossier contient des données de marché Lightning (frais moyens, liquidité globale, tendances de croissance, etc.).

Utilité :
- Permettre au RAG de contextualiser les recommandations par rapport à l'état du réseau.
- Alimenter les analyses comparatives et les projections.

Ajoutez ici des fichiers CSV, JSON ou API externes, accompagnés d'une description de la source. 