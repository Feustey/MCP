# dashboards

Ce dossier contient des snapshots ou exports de tableaux de bord Lightning (ThunderHub, Amboss, LNRouter, etc.), organisés par nœud et par date.

Utilité :
- Permettre au RAG d'enrichir les rapports avec des analyses visuelles et le suivi des KPIs.
- Faciliter la détection d'anomalies ou de tendances sur les performances des nœuds.

Ajoutez ici des images, PDF ou exports pertinents de dashboards. 