# playbooks

Ce dossier contient des procédures opérationnelles (playbooks) détaillées pour les tâches courantes sur un nœud Lightning (ouverture de canal, rebalancement, upgrade, backup, etc.).

Utilité :
- Permettre au RAG de générer des guides d'action personnalisés et adaptés à chaque situation.
- Standardiser les bonnes pratiques opérationnelles.

Ajoutez ici des fichiers Markdown ou texte décrivant chaque procédure. 