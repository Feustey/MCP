# Rapport d'analyse avancée

Date: 2025-05-08 20:52:54

## Profil: normal

- **Recommandation globale**: NO_ACTION
- **Score du nœud**: 0.85/1.0
- **Taux de succès**: 90.5%
- **Forwards journaliers**: 127

## Profil: saturated

- **Recommandation globale**: NO_ACTION
- **Score du nœud**: 0.69/1.0
- **Taux de succès**: 62.5%
- **Forwards journaliers**: 267

## Profil: unstable

- **Recommandation globale**: NO_ACTION
- **Score du nœud**: 0.80/1.0
- **Taux de succès**: 78.0%
- **Forwards journaliers**: 151

## Profil: abused

- **Recommandation globale**: CLOSE_CHANNEL
- **Score du nœud**: 0.56/1.0
- **Taux de succès**: 44.3%
- **Forwards journaliers**: 172

## Profil: routing_hub

- **Recommandation globale**: NO_ACTION
- **Score du nœud**: 0.92/1.0
- **Taux de succès**: 93.3%
- **Forwards journaliers**: 791

## Profil: dead_node

- **Recommandation globale**: CLOSE_CHANNEL
- **Score du nœud**: 0.26/1.0
- **Taux de succès**: 5.2%
- **Forwards journaliers**: 1

